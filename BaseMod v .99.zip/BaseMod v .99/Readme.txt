All credits to the development of 3DMigoto go to the original developers: https://github.com/bo3b/3Dmigoto/releases.  
We simply customized it to work with this game.  Special thanks also to Fraggerman and others from the Fairy Tail mod server.

This basemod, or another version of it, is necessary to use any other 3DMigoto-based mods.  
You also must run FFVIIR in DirecX11 mode for this basemod to work.  Instructions for launching the game in DX11 mode can be found online, 
or in the OpenFF7R Discord server: https://discord.com/invite/qdxhFwT3Tr

To install, simply unzip these files in the \Final Fantasy VII Remake Intergrade\End\Binaries\Win64 directory, and launch the game in DX11 mode.  
Extract any 3DMigoto-based mods to \Final Fantasy VII Remake Intergrade\End\Binaries\Win64\Mods.

Pressing F1 brings up a help menu, and F3 enables or disables mods.